import React from 'react';

export default function Banner(){
    return(
        <div className="home_page_banner">
            <img className="" alt="banner"/>
        </div>
    );
}