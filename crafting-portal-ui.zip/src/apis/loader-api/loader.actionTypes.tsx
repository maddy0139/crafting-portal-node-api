import {createActionTypes} from '../../utils/reduxUtils';

const ActionTypes = createActionTypes([
    'SHOW_LOADER',
    'HIDE_LOADER'
]);

export default ActionTypes;
