import {createActionTypes} from '../../utils/reduxUtils';

const ActionTypes = createActionTypes([
    'SHOW_SUCCESS_NOTIFICATION',
    'HIDE_SUCCESS_NOTIFICATION'
]);

export default ActionTypes;
